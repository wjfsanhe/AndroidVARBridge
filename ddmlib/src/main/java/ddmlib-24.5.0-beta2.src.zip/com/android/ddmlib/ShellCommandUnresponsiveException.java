package com.android.ddmlib;

public class ShellCommandUnresponsiveException extends Exception
{
  private static final long serialVersionUID = 1L;
}

/* Location:           /disk/B/share/ddmlib/ddmlib-24.5.0-beta2.jar
 * Qualified Name:     com.android.ddmlib.ShellCommandUnresponsiveException
 * JD-Core Version:    0.6.2
 */