package com.android.ddmlib;

public abstract interface IStackTraceInfo
{
  public abstract StackTraceElement[] getStackTrace();
}

/* Location:           /disk/B/share/ddmlib/ddmlib-24.5.0-beta2.jar
 * Qualified Name:     com.android.ddmlib.IStackTraceInfo
 * JD-Core Version:    0.6.2
 */