/*      */ package com.android.ddmlib;
/*      */ 
/*      */ import com.android.ddmlib.log.LogReceiver;
/*      */ import com.google.common.base.CharMatcher;
/*      */ import com.google.common.base.Function;
/*      */ import com.google.common.base.Joiner;
/*      */ import com.google.common.base.Splitter;
/*      */ import com.google.common.collect.ImmutableList;
/*      */ import com.google.common.collect.Lists;
/*      */ import com.google.common.collect.Sets;
/*      */ import com.google.common.util.concurrent.Atomics;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.nio.channels.SocketChannel;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.CountDownLatch;
/*      */ import java.util.concurrent.ExecutionException;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ final class Device
/*      */   implements IDevice
/*      */ {
/*      */   static final String RE_EMULATOR_SN = "emulator-(\\d+)";
/*      */   private final String mSerialNumber;
/*   67 */   private String mAvdName = null;
/*      */ 
/*   70 */   private IDevice.DeviceState mState = null;
/*      */ 
/*   73 */   private boolean mIsRoot = false;
/*      */ 
/*   76 */   private final PropertyFetcher mPropFetcher = new PropertyFetcher(this);
/*   77 */   private final Map<String, String> mMountPoints = new HashMap();
/*      */ 
/*   79 */   private final BatteryFetcher mBatteryFetcher = new BatteryFetcher(this);
/*      */ 
/*   81 */   private final List<Client> mClients = new ArrayList();
/*      */ 
/*   85 */   private final Map<Integer, String> mClientInfo = new ConcurrentHashMap();
/*      */   private DeviceMonitor mMonitor;
/*      */   private static final String LOG_TAG = "Device";
/*      */   private static final char SEPARATOR = '-';
/*      */   private static final String UNKNOWN_PACKAGE = "";
/*      */   private static final long GET_PROP_TIMEOUT_MS = 100L;
/*      */   private static final long INITIAL_GET_PROP_TIMEOUT_MS = 250L;
/*      */   private static final int QUERY_IS_ROOT_TIMEOUT_MS = 1000;
/*  109 */   private static final long INSTALL_TIMEOUT_MINUTES = time;
/*      */   private SocketChannel mSocketChannel;
/*  117 */   private Integer mLastBatteryLevel = null;
/*  118 */   private long mLastBatteryCheckTime = 0L;
/*      */   private static final String SCREEN_RECORDER_DEVICE_PATH = "/system/bin/screenrecord";
/*      */   private static final long LS_TIMEOUT_SEC = 2L;
/*      */   private Boolean mHasScreenRecorder;
/*      */   private Set<String> mHardwareCharacteristics;
/*      */   private int mApiLevel;
/*      */   private String mName;
/* 1040 */   private static final CharMatcher UNSAFE_PM_INSTALL_SESSION_SPLIT_NAME_CHARS = CharMatcher.inRange('a', 'z').or(CharMatcher.inRange('A', 'Z')).or(CharMatcher.anyOf("_-")).negate();
/*      */ 
/*      */   public String getSerialNumber()
/*      */   {
/*  181 */     return this.mSerialNumber;
/*      */   }
/*      */ 
/*      */   public String getAvdName()
/*      */   {
/*  186 */     return this.mAvdName;
/*      */   }
/*      */ 
/*      */   void setAvdName(String avdName)
/*      */   {
/*  193 */     if (!isEmulator()) {
/*  194 */       throw new IllegalArgumentException("Cannot set the AVD name of the device is not an emulator");
/*      */     }
/*      */ 
/*  198 */     this.mAvdName = avdName;
/*      */   }
/*      */ 
/*      */   public String getName()
/*      */   {
/*  203 */     if (this.mName != null) {
/*  204 */       return this.mName;
/*      */     }
/*      */ 
/*  207 */     if (isOnline())
/*      */     {
/*  209 */       this.mName = constructName();
/*  210 */       return this.mName;
/*      */     }
/*  212 */     return constructName();
/*      */   }
/*      */ 
/*      */   private String constructName()
/*      */   {
/*  217 */     if (isEmulator()) {
/*  218 */       String avdName = getAvdName();
/*  219 */       if (avdName != null) {
/*  220 */         return String.format("%s [%s]", new Object[] { avdName, getSerialNumber() });
/*      */       }
/*  222 */       return getSerialNumber();
/*      */     }
/*      */ 
/*  225 */     String manufacturer = null;
/*  226 */     String model = null;
/*      */     try
/*      */     {
/*  229 */       manufacturer = cleanupStringForDisplay(getProperty("ro.product.manufacturer"));
/*  230 */       model = cleanupStringForDisplay(getProperty("ro.product.model"));
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */     }
/*      */ 
/*  236 */     StringBuilder sb = new StringBuilder(20);
/*      */ 
/*  238 */     if (manufacturer != null) {
/*  239 */       sb.append(manufacturer);
/*  240 */       sb.append('-');
/*      */     }
/*      */ 
/*  243 */     if (model != null) {
/*  244 */       sb.append(model);
/*  245 */       sb.append('-');
/*      */     }
/*      */ 
/*  248 */     sb.append(getSerialNumber());
/*  249 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   private String cleanupStringForDisplay(String s)
/*      */   {
/*  254 */     if (s == null) {
/*  255 */       return null;
/*      */     }
/*      */ 
/*  258 */     StringBuilder sb = new StringBuilder(s.length());
/*  259 */     for (int i = 0; i < s.length(); i++) {
/*  260 */       char c = s.charAt(i);
/*      */ 
/*  262 */       if (Character.isLetterOrDigit(c))
/*  263 */         sb.append(Character.toLowerCase(c));
/*      */       else {
/*  265 */         sb.append('_');
/*      */       }
/*      */     }
/*      */ 
/*  269 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public IDevice.DeviceState getState()
/*      */   {
/*  278 */     return this.mState;
/*      */   }
/*      */ 
/*      */   void setState(IDevice.DeviceState state)
/*      */   {
/*  285 */     this.mState = state;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getProperties()
/*      */   {
/*  290 */     return Collections.unmodifiableMap(this.mPropFetcher.getProperties());
/*      */   }
/*      */ 
/*      */   public int getPropertyCount()
/*      */   {
/*  295 */     return this.mPropFetcher.getProperties().size();
/*      */   }
/*      */ 
/*      */   public String getProperty(String name)
/*      */   {
/*  300 */     Map properties = this.mPropFetcher.getProperties();
/*  301 */     long timeout = properties.isEmpty() ? 250L : 100L;
/*      */ 
/*  303 */     Future future = this.mPropFetcher.getProperty(name);
/*      */     try {
/*  305 */       return (String)future.get(timeout, TimeUnit.MILLISECONDS);
/*      */     }
/*      */     catch (InterruptedException e) {
/*      */     }
/*      */     catch (ExecutionException e) {
/*      */     }
/*      */     catch (java.util.concurrent.TimeoutException e) {
/*      */     }
/*  313 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean arePropertiesSet()
/*      */   {
/*  318 */     return this.mPropFetcher.arePropertiesSet();
/*      */   }
/*      */ 
/*      */   public String getPropertyCacheOrSync(String name)
/*      */     throws TimeoutException, AdbCommandRejectedException, ShellCommandUnresponsiveException, IOException
/*      */   {
/*  324 */     Future future = this.mPropFetcher.getProperty(name);
/*      */     try {
/*  326 */       return (String)future.get();
/*      */     }
/*      */     catch (InterruptedException e) {
/*      */     }
/*      */     catch (ExecutionException e) {
/*      */     }
/*  332 */     return null;
/*      */   }
/*      */ 
/*      */   public String getPropertySync(String name)
/*      */     throws TimeoutException, AdbCommandRejectedException, ShellCommandUnresponsiveException, IOException
/*      */   {
/*  338 */     Future future = this.mPropFetcher.getProperty(name);
/*      */     try {
/*  340 */       return (String)future.get();
/*      */     }
/*      */     catch (InterruptedException e) {
/*      */     }
/*      */     catch (ExecutionException e) {
/*      */     }
/*  346 */     return null;
/*      */   }
/*      */ 
/*      */   public Future<String> getSystemProperty(String name)
/*      */   {
/*  352 */     return this.mPropFetcher.getProperty(name);
/*      */   }
/*      */ 
/*      */   public boolean supportsFeature(IDevice.Feature feature)
/*      */   {
/*  357 */     switch (3.$SwitchMap$com$android$ddmlib$IDevice$Feature[feature.ordinal()]) {
/*      */     case 1:
/*  359 */       if (getApiLevel() < 19) {
/*  360 */         return false;
/*      */       }
/*  362 */       if (this.mHasScreenRecorder == null) {
/*  363 */         this.mHasScreenRecorder = Boolean.valueOf(hasBinary("/system/bin/screenrecord"));
/*      */       }
/*  365 */       return this.mHasScreenRecorder.booleanValue();
/*      */     case 2:
/*  367 */       return getApiLevel() >= 19;
/*      */     }
/*  369 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsFeature(IDevice.HardwareFeature feature)
/*      */   {
/*  378 */     if (this.mHardwareCharacteristics == null) {
/*      */       try {
/*  380 */         String characteristics = getProperty("ro.build.characteristics");
/*  381 */         if (characteristics == null) {
/*  382 */           return false;
/*      */         }
/*      */ 
/*  385 */         this.mHardwareCharacteristics = Sets.newHashSet(Splitter.on(',').split(characteristics));
/*      */       } catch (Exception e) {
/*  387 */         this.mHardwareCharacteristics = Collections.emptySet();
/*      */       }
/*      */     }
/*      */ 
/*  391 */     return this.mHardwareCharacteristics.contains(feature.getCharacteristic());
/*      */   }
/*      */ 
/*      */   public int getApiLevel()
/*      */   {
/*  396 */     if (this.mApiLevel > 0) {
/*  397 */       return this.mApiLevel;
/*      */     }
/*      */     try
/*      */     {
/*  401 */       String buildApi = getProperty("ro.build.version.sdk");
/*  402 */       this.mApiLevel = (buildApi == null ? -1 : Integer.parseInt(buildApi));
/*  403 */       return this.mApiLevel; } catch (Exception e) {
/*      */     }
/*  405 */     return -1;
/*      */   }
/*      */ 
/*      */   private boolean hasBinary(String path)
/*      */   {
/*  410 */     CountDownLatch latch = new CountDownLatch(1);
/*  411 */     CollectingOutputReceiver receiver = new CollectingOutputReceiver(latch);
/*      */     try {
/*  413 */       executeShellCommand(new StringBuilder().append("ls ").append(path).toString(), receiver, 2L, TimeUnit.SECONDS);
/*      */     } catch (Exception e) {
/*  415 */       return false;
/*      */     }
/*      */     try
/*      */     {
/*  419 */       latch.await(2L, TimeUnit.SECONDS);
/*      */     } catch (InterruptedException e) {
/*  421 */       return false;
/*      */     }
/*      */ 
/*  424 */     String value = receiver.getOutput().trim();
/*  425 */     return !value.endsWith("No such file or directory");
/*      */   }
/*      */ 
/*      */   public String getMountPoint(String name)
/*      */   {
/*  431 */     String mount = (String)this.mMountPoints.get(name);
/*  432 */     if (mount == null)
/*      */       try {
/*  434 */         mount = queryMountPoint(name);
/*  435 */         this.mMountPoints.put(name, mount);
/*      */       } catch (TimeoutException ignored) {
/*      */       } catch (AdbCommandRejectedException ignored) {
/*      */       } catch (ShellCommandUnresponsiveException ignored) {
/*      */       }
/*      */       catch (IOException ignored) {
/*      */       }
/*  442 */     return mount;
/*      */   }
/*      */ 
/*      */   private String queryMountPoint(String name)
/*      */     throws TimeoutException, AdbCommandRejectedException, ShellCommandUnresponsiveException, IOException
/*      */   {
/*  450 */     final AtomicReference ref = Atomics.newReference();
/*  451 */     executeShellCommand(new StringBuilder().append("echo $").append(name).toString(), new MultiLineReceiver()
/*      */     {
/*      */       public boolean isCancelled() {
/*  454 */         return false;
/*      */       }
/*      */ 
/*      */       public void processNewLines(String[] lines)
/*      */       {
/*  459 */         for (String line : lines)
/*  460 */           if (!line.isEmpty())
/*      */           {
/*  462 */             ref.set(line);
/*      */           }
/*      */       }
/*      */     });
/*  467 */     return (String)ref.get();
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/*  472 */     return this.mSerialNumber;
/*      */   }
/*      */ 
/*      */   public boolean isOnline()
/*      */   {
/*  481 */     return this.mState == IDevice.DeviceState.ONLINE;
/*      */   }
/*      */ 
/*      */   public boolean isEmulator()
/*      */   {
/*  490 */     return this.mSerialNumber.matches("emulator-(\\d+)");
/*      */   }
/*      */ 
/*      */   public boolean isOffline()
/*      */   {
/*  499 */     return this.mState == IDevice.DeviceState.OFFLINE;
/*      */   }
/*      */ 
/*      */   public boolean isBootLoader()
/*      */   {
/*  508 */     return this.mState == IDevice.DeviceState.BOOTLOADER;
/*      */   }
/*      */ 
/*      */   public SyncService getSyncService()
/*      */     throws TimeoutException, AdbCommandRejectedException, IOException
/*      */   {
/*  518 */     SyncService syncService = new SyncService(AndroidDebugBridge.getSocketAddress(), this);
/*  519 */     if (syncService.openSync()) {
/*  520 */       return syncService;
/*      */     }
/*      */ 
/*  523 */     return null;
/*      */   }
/*      */ 
/*      */   public FileListingService getFileListingService()
/*      */   {
/*  532 */     return new FileListingService(this);
/*      */   }
/*      */ 
/*      */   public RawImage getScreenshot()
/*      */     throws TimeoutException, AdbCommandRejectedException, IOException
/*      */   {
/*  538 */     return getScreenshot(0L, TimeUnit.MILLISECONDS);
/*      */   }
/*      */ 
/*      */   public RawImage getScreenshot(long timeout, TimeUnit unit)
/*      */     throws TimeoutException, AdbCommandRejectedException, IOException
/*      */   {
/*  544 */     return AdbHelper.getFrameBuffer(AndroidDebugBridge.getSocketAddress(), this, timeout, unit);
/*      */   }
/*      */ 
/*      */   public void startScreenRecorder(String remoteFilePath, ScreenRecorderOptions options, IShellOutputReceiver receiver)
/*      */     throws TimeoutException, AdbCommandRejectedException, IOException, ShellCommandUnresponsiveException
/*      */   {
/*  551 */     executeShellCommand(getScreenRecorderCommand(remoteFilePath, options), receiver, 0L, null);
/*      */   }
/*      */ 
/*      */   static String getScreenRecorderCommand(String remoteFilePath, ScreenRecorderOptions options)
/*      */   {
/*  557 */     StringBuilder sb = new StringBuilder();
/*      */ 
/*  559 */     sb.append("screenrecord");
/*  560 */     sb.append(' ');
/*      */ 
/*  562 */     if ((options.width > 0) && (options.height > 0)) {
/*  563 */       sb.append("--size ");
/*  564 */       sb.append(options.width);
/*  565 */       sb.append('x');
/*  566 */       sb.append(options.height);
/*  567 */       sb.append(' ');
/*      */     }
/*      */ 
/*  570 */     if (options.bitrateMbps > 0) {
/*  571 */       sb.append("--bit-rate ");
/*  572 */       sb.append(options.bitrateMbps * 1000000);
/*  573 */       sb.append(' ');
/*      */     }
/*      */ 
/*  576 */     if (options.timeLimit > 0L) {
/*  577 */       sb.append("--time-limit ");
/*  578 */       long seconds = TimeUnit.SECONDS.convert(options.timeLimit, options.timeLimitUnits);
/*  579 */       if (seconds > 180L) {
/*  580 */         seconds = 180L;
/*      */       }
/*  582 */       sb.append(seconds);
/*  583 */       sb.append(' ');
/*      */     }
/*      */ 
/*  586 */     sb.append(remoteFilePath);
/*      */ 
/*  588 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public void executeShellCommand(String command, IShellOutputReceiver receiver)
/*      */     throws TimeoutException, AdbCommandRejectedException, ShellCommandUnresponsiveException, IOException
/*      */   {
/*  595 */     AdbHelper.executeRemoteCommand(AndroidDebugBridge.getSocketAddress(), command, this, receiver, DdmPreferences.getTimeOut());
/*      */   }
/*      */ 
/*      */   public void executeShellCommand(String command, IShellOutputReceiver receiver, int maxTimeToOutputResponse)
/*      */     throws TimeoutException, AdbCommandRejectedException, ShellCommandUnresponsiveException, IOException
/*      */   {
/*  604 */     AdbHelper.executeRemoteCommand(AndroidDebugBridge.getSocketAddress(), command, this, receiver, maxTimeToOutputResponse);
/*      */   }
/*      */ 
/*      */   public void executeShellCommand(String command, IShellOutputReceiver receiver, long maxTimeToOutputResponse, TimeUnit maxTimeUnits)
/*      */     throws TimeoutException, AdbCommandRejectedException, ShellCommandUnresponsiveException, IOException
/*      */   {
/*  613 */     AdbHelper.executeRemoteCommand(AndroidDebugBridge.getSocketAddress(), command, this, receiver, maxTimeToOutputResponse, maxTimeUnits);
/*      */   }
/*      */ 
/*      */   public void runEventLogService(LogReceiver receiver)
/*      */     throws TimeoutException, AdbCommandRejectedException, IOException
/*      */   {
/*  620 */     AdbHelper.runEventLogService(AndroidDebugBridge.getSocketAddress(), this, receiver);
/*      */   }
/*      */ 
/*      */   public void runLogService(String logname, LogReceiver receiver)
/*      */     throws TimeoutException, AdbCommandRejectedException, IOException
/*      */   {
/*  626 */     AdbHelper.runLogService(AndroidDebugBridge.getSocketAddress(), this, logname, receiver);
/*      */   }
/*      */ 
/*      */   public void createForward(int localPort, int remotePort)
/*      */     throws TimeoutException, AdbCommandRejectedException, IOException
/*      */   {
/*  632 */     AdbHelper.createForward(AndroidDebugBridge.getSocketAddress(), this, String.format("tcp:%d", new Object[] { Integer.valueOf(localPort) }), String.format("tcp:%d", new Object[] { Integer.valueOf(remotePort) }));
/*      */   }
/*      */ 
/*      */   public void createForward(int localPort, String remoteSocketName, IDevice.DeviceUnixSocketNamespace namespace)
/*      */     throws TimeoutException, AdbCommandRejectedException, IOException
/*      */   {
/*  641 */     AdbHelper.createForward(AndroidDebugBridge.getSocketAddress(), this, String.format("tcp:%d", new Object[] { Integer.valueOf(localPort) }), String.format("%s:%s", new Object[] { namespace.getType(), remoteSocketName }));
/*      */   }
/*      */ 
/*      */   public void removeForward(int localPort, int remotePort)
/*      */     throws TimeoutException, AdbCommandRejectedException, IOException
/*      */   {
/*  649 */     AdbHelper.removeForward(AndroidDebugBridge.getSocketAddress(), this, String.format("tcp:%d", new Object[] { Integer.valueOf(localPort) }), String.format("tcp:%d", new Object[] { Integer.valueOf(remotePort) }));
/*      */   }
/*      */ 
/*      */   public void removeForward(int localPort, String remoteSocketName, IDevice.DeviceUnixSocketNamespace namespace)
/*      */     throws TimeoutException, AdbCommandRejectedException, IOException
/*      */   {
/*  658 */     AdbHelper.removeForward(AndroidDebugBridge.getSocketAddress(), this, String.format("tcp:%d", new Object[] { Integer.valueOf(localPort) }), String.format("%s:%s", new Object[] { namespace.getType(), remoteSocketName }));
/*      */   }
/*      */ 
/*      */   Device(DeviceMonitor monitor, String serialNumber, IDevice.DeviceState deviceState)
/*      */   {
/*  664 */     this.mMonitor = monitor;
/*  665 */     this.mSerialNumber = serialNumber;
/*  666 */     this.mState = deviceState;
/*      */   }
/*      */ 
/*      */   DeviceMonitor getMonitor() {
/*  670 */     return this.mMonitor;
/*      */   }
/*      */ 
/*      */   public boolean hasClients()
/*      */   {
/*  675 */     synchronized (this.mClients) {
/*  676 */       return !this.mClients.isEmpty();
/*      */     }
/*      */   }
/*      */ 
/*      */   public Client[] getClients()
/*      */   {
/*  682 */     synchronized (this.mClients) {
/*  683 */       return (Client[])this.mClients.toArray(new Client[this.mClients.size()]);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Client getClient(String applicationName)
/*      */   {
/*  689 */     synchronized (this.mClients) {
/*  690 */       for (Client c : this.mClients) {
/*  691 */         if (applicationName.equals(c.getClientData().getClientDescription())) {
/*  692 */           return c;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  697 */     return null;
/*      */   }
/*      */ 
/*      */   void addClient(Client client) {
/*  701 */     synchronized (this.mClients) {
/*  702 */       this.mClients.add(client);
/*      */     }
/*      */ 
/*  705 */     addClientInfo(client);
/*      */   }
/*      */ 
/*      */   List<Client> getClientList() {
/*  709 */     return this.mClients;
/*      */   }
/*      */ 
/*      */   void clearClientList() {
/*  713 */     synchronized (this.mClients) {
/*  714 */       this.mClients.clear();
/*      */     }
/*      */ 
/*  717 */     clearClientInfo();
/*      */   }
/*      */ 
/*      */   void removeClient(Client client, boolean notify)
/*      */   {
/*  726 */     this.mMonitor.addPortToAvailableList(client.getDebuggerListenPort());
/*  727 */     synchronized (this.mClients) {
/*  728 */       this.mClients.remove(client);
/*      */     }
/*  730 */     if (notify) {
/*  731 */       this.mMonitor.getServer().deviceChanged(this, 2);
/*      */     }
/*      */ 
/*  734 */     removeClientInfo(client);
/*      */   }
/*      */ 
/*      */   void setClientMonitoringSocket(SocketChannel socketChannel)
/*      */   {
/*  739 */     this.mSocketChannel = socketChannel;
/*      */   }
/*      */ 
/*      */   SocketChannel getClientMonitoringSocket()
/*      */   {
/*  749 */     return this.mSocketChannel;
/*      */   }
/*      */ 
/*      */   void update(int changeMask) {
/*  753 */     this.mMonitor.getServer().deviceChanged(this, changeMask);
/*      */   }
/*      */ 
/*      */   void update(Client client, int changeMask) {
/*  757 */     this.mMonitor.getServer().clientChanged(client, changeMask);
/*  758 */     updateClientInfo(client, changeMask);
/*      */   }
/*      */ 
/*      */   void setMountingPoint(String name, String value) {
/*  762 */     this.mMountPoints.put(name, value);
/*      */   }
/*      */ 
/*      */   private void addClientInfo(Client client) {
/*  766 */     ClientData cd = client.getClientData();
/*  767 */     setClientInfo(cd.getPid(), cd.getClientDescription());
/*      */   }
/*      */ 
/*      */   private void updateClientInfo(Client client, int changeMask) {
/*  771 */     if ((changeMask & 0x1) == 1)
/*  772 */       addClientInfo(client);
/*      */   }
/*      */ 
/*      */   private void removeClientInfo(Client client)
/*      */   {
/*  777 */     int pid = client.getClientData().getPid();
/*  778 */     this.mClientInfo.remove(Integer.valueOf(pid));
/*      */   }
/*      */ 
/*      */   private void clearClientInfo() {
/*  782 */     this.mClientInfo.clear();
/*      */   }
/*      */ 
/*      */   private void setClientInfo(int pid, String pkgName) {
/*  786 */     if (pkgName == null) {
/*  787 */       pkgName = "";
/*      */     }
/*      */ 
/*  790 */     this.mClientInfo.put(Integer.valueOf(pid), pkgName);
/*      */   }
/*      */ 
/*      */   public String getClientName(int pid)
/*      */   {
/*  795 */     String pkgName = (String)this.mClientInfo.get(Integer.valueOf(pid));
/*  796 */     return pkgName == null ? "" : pkgName;
/*      */   }
/*      */ 
/*      */   public void pushFile(String local, String remote)
/*      */     throws IOException, AdbCommandRejectedException, TimeoutException, SyncException
/*      */   {
/*  802 */     SyncService sync = null;
/*      */     try {
/*  804 */       String targetFileName = getFileName(local);
/*      */ 
/*  806 */       Log.d(targetFileName, String.format("Uploading %1$s onto device '%2$s'", new Object[] { targetFileName, getSerialNumber() }));
/*      */ 
/*  809 */       sync = getSyncService();
/*  810 */       if (sync != null) {
/*  811 */         String message = String.format("Uploading file onto device '%1$s'", new Object[] { getSerialNumber() });
/*      */ 
/*  813 */         Log.d("Device", message);
/*  814 */         sync.pushFile(local, remote, SyncService.getNullProgressMonitor());
/*      */       } else {
/*  816 */         throw new IOException("Unable to open sync connection!");
/*      */       }
/*      */     } catch (TimeoutException e) {
/*  819 */       Log.e("Device", "Error during Sync: timeout.");
/*  820 */       throw e;
/*      */     }
/*      */     catch (SyncException e) {
/*  823 */       Log.e("Device", String.format("Error during Sync: %1$s", new Object[] { e.getMessage() }));
/*  824 */       throw e;
/*      */     }
/*      */     catch (IOException e) {
/*  827 */       Log.e("Device", String.format("Error during Sync: %1$s", new Object[] { e.getMessage() }));
/*  828 */       throw e;
/*      */     }
/*      */     finally {
/*  831 */       if (sync != null)
/*  832 */         sync.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void pullFile(String remote, String local)
/*      */     throws IOException, AdbCommandRejectedException, TimeoutException, SyncException
/*      */   {
/*  840 */     SyncService sync = null;
/*      */     try {
/*  842 */       String targetFileName = getFileName(remote);
/*      */ 
/*  844 */       Log.d(targetFileName, String.format("Downloading %1$s from device '%2$s'", new Object[] { targetFileName, getSerialNumber() }));
/*      */ 
/*  847 */       sync = getSyncService();
/*  848 */       if (sync != null) {
/*  849 */         String message = String.format("Downloading file from device '%1$s'", new Object[] { getSerialNumber() });
/*      */ 
/*  851 */         Log.d("Device", message);
/*  852 */         sync.pullFile(remote, local, SyncService.getNullProgressMonitor());
/*      */       } else {
/*  854 */         throw new IOException("Unable to open sync connection!");
/*      */       }
/*      */     } catch (TimeoutException e) {
/*  857 */       Log.e("Device", "Error during Sync: timeout.");
/*  858 */       throw e;
/*      */     }
/*      */     catch (SyncException e) {
/*  861 */       Log.e("Device", String.format("Error during Sync: %1$s", new Object[] { e.getMessage() }));
/*  862 */       throw e;
/*      */     }
/*      */     catch (IOException e) {
/*  865 */       Log.e("Device", String.format("Error during Sync: %1$s", new Object[] { e.getMessage() }));
/*  866 */       throw e;
/*      */     }
/*      */     finally {
/*  869 */       if (sync != null)
/*  870 */         sync.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void installPackage(String packageFilePath, boolean reinstall, String[] extraArgs)
/*      */     throws InstallException
/*      */   {
/*      */     try
/*      */     {
/*  880 */       String remoteFilePath = syncPackageToDevice(packageFilePath);
/*  881 */       installRemotePackage(remoteFilePath, reinstall, extraArgs);
/*  882 */       removeRemotePackage(remoteFilePath);
/*      */     } catch (IOException e) {
/*  884 */       throw new InstallException(e);
/*      */     } catch (AdbCommandRejectedException e) {
/*  886 */       throw new InstallException(e);
/*      */     } catch (TimeoutException e) {
/*  888 */       throw new InstallException(e);
/*      */     } catch (SyncException e) {
/*  890 */       throw new InstallException(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void installPackages(List<String> apkFilePaths, int timeOutInMs, boolean reinstall, String[] extraArgs)
/*      */     throws InstallException
/*      */   {
/*  898 */     assert (!apkFilePaths.isEmpty());
/*      */ 
/*  900 */     if (getApiLevel() < 21) {
/*  901 */       Log.w("Internal error : installPackages invoked with device < 21 for %s", Joiner.on(",").join(apkFilePaths));
/*      */ 
/*  904 */       if (apkFilePaths.size() == 1) {
/*  905 */         installPackage((String)apkFilePaths.get(0), reinstall, extraArgs);
/*  906 */         return;
/*      */       }
/*  908 */       Log.e("Internal error : installPackages invoked with device < 21 for multiple APK : %s", Joiner.on(",").join(apkFilePaths));
/*      */ 
/*  910 */       throw new InstallException(new StringBuilder().append("Internal error : installPackages invoked with device < 21 for multiple APK : ").append(Joiner.on(",").join(apkFilePaths)).toString());
/*      */     }
/*      */ 
/*  914 */     String mainPackageFilePath = (String)apkFilePaths.get(0);
/*  915 */     Log.d(mainPackageFilePath, String.format("Uploading main %1$s and %2$s split APKs onto device '%3$s'", new Object[] { mainPackageFilePath, Joiner.on(',').join(apkFilePaths), getSerialNumber() }));
/*      */     try
/*      */     {
/*  923 */       List extraArgsList = extraArgs != null ? ImmutableList.copyOf(extraArgs) : ImmutableList.of();
/*      */ 
/*  927 */       String sessionId = createMultiInstallSession(apkFilePaths, extraArgsList, reinstall);
/*  928 */       if (sessionId == null) {
/*  929 */         Log.d(mainPackageFilePath, "Failed to establish session, quit installation");
/*  930 */         throw new InstallException("Failed to establish session");
/*      */       }
/*  932 */       Log.d(mainPackageFilePath, String.format("Established session id=%1$s", new Object[] { sessionId }));
/*      */ 
/*  935 */       int index = 0;
/*  936 */       boolean allUploadSucceeded = true;
/*  937 */       while ((allUploadSucceeded) && (index < apkFilePaths.size())) {
/*  938 */         allUploadSucceeded = uploadAPK(sessionId, (String)apkFilePaths.get(index), index++, timeOutInMs);
/*      */       }
/*      */ 
/*  942 */       String command = allUploadSucceeded ? new StringBuilder().append("pm install-commit ").append(sessionId).toString() : new StringBuilder().append("pm install-abandon ").append(sessionId).toString();
/*      */ 
/*  945 */       InstallReceiver receiver = new InstallReceiver();
/*  946 */       executeShellCommand(command, receiver, timeOutInMs, TimeUnit.MILLISECONDS);
/*  947 */       String errorMessage = receiver.getErrorMessage();
/*  948 */       if (errorMessage != null) {
/*  949 */         String message = String.format("Failed to finalize session : %1$s", new Object[] { errorMessage });
/*  950 */         Log.e(mainPackageFilePath, message);
/*  951 */         throw new InstallException(message);
/*      */       }
/*      */ 
/*  955 */       if (!allUploadSucceeded)
/*  956 */         throw new InstallException("Unable to upload some APKs");
/*      */     }
/*      */     catch (TimeoutException e) {
/*  959 */       Log.e("Device", "Error during Sync: timeout.");
/*  960 */       throw new InstallException(e);
/*      */     }
/*      */     catch (IOException e) {
/*  963 */       Log.e("Device", String.format("Error during Sync: %1$s", new Object[] { e.getMessage() }));
/*  964 */       throw new InstallException(e);
/*      */     }
/*      */     catch (AdbCommandRejectedException e) {
/*  967 */       throw new InstallException(e);
/*      */     } catch (ShellCommandUnresponsiveException e) {
/*  969 */       Log.e("Device", String.format("Error during shell execution: %1$s", new Object[] { e.getMessage() }));
/*  970 */       throw new InstallException(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   private String createMultiInstallSession(List<String> apkFileNames, Collection<String> extraArgs, boolean reinstall)
/*      */     throws TimeoutException, AdbCommandRejectedException, ShellCommandUnresponsiveException, IOException
/*      */   {
/* 1012 */     List apkFiles = Lists.transform(apkFileNames, new Function()
/*      */     {
/*      */       public File apply(String input) {
/* 1015 */         return new File(input);
/*      */       }
/*      */     });
/* 1019 */     long totalFileSize = 0L;
/* 1020 */     for (File apkFile : apkFiles) {
/* 1021 */       if ((apkFile.exists()) && (apkFile.isFile()))
/* 1022 */         totalFileSize += apkFile.length();
/*      */       else {
/* 1024 */         throw new IllegalArgumentException(new StringBuilder().append(apkFile.getAbsolutePath()).append(" is not a file").toString());
/*      */       }
/*      */     }
/* 1027 */     StringBuilder parameters = new StringBuilder();
/* 1028 */     if (reinstall) {
/* 1029 */       parameters.append("-r ");
/*      */     }
/* 1031 */     parameters.append(Joiner.on(' ').join(extraArgs));
/* 1032 */     MultiInstallReceiver receiver = new MultiInstallReceiver(null);
/* 1033 */     String cmd = String.format("pm install-create %1$s -S %2$d", new Object[] { parameters.toString(), Long.valueOf(totalFileSize) });
/*      */ 
/* 1036 */     executeShellCommand(cmd, receiver, DdmPreferences.getTimeOut());
/* 1037 */     return receiver.getSessionId();
/*      */   }
/*      */ 
/*      */   private boolean uploadAPK(String sessionId, String apkFilePath, int uniqueId, int timeOutInMs)
/*      */   {
/* 1045 */     Log.d(sessionId, String.format("Uploading APK %1$s ", new Object[] { apkFilePath }));
/* 1046 */     File fileToUpload = new File(apkFilePath);
/* 1047 */     if (!fileToUpload.exists()) {
/* 1048 */       Log.e(sessionId, String.format("File not found: %1$s", new Object[] { apkFilePath }));
/* 1049 */       return false;
/*      */     }
/* 1051 */     if (fileToUpload.isDirectory()) {
/* 1052 */       Log.e(sessionId, String.format("Directory upload not supported: %1$s", new Object[] { apkFilePath }));
/* 1053 */       return false;
/*      */     }
/* 1055 */     String baseName = fileToUpload.getName().lastIndexOf(46) != -1 ? fileToUpload.getName().substring(0, fileToUpload.getName().lastIndexOf(46)) : fileToUpload.getName();
/*      */ 
/* 1059 */     baseName = UNSAFE_PM_INSTALL_SESSION_SPLIT_NAME_CHARS.replaceFrom(baseName, '_');
/*      */ 
/* 1061 */     String command = String.format("pm install-write -S %d %s %d_%s -", new Object[] { Long.valueOf(fileToUpload.length()), sessionId, Integer.valueOf(uniqueId), baseName });
/*      */ 
/* 1064 */     Log.d(sessionId, String.format("Executing : %1$s", new Object[] { command }));
/* 1065 */     InputStream inputStream = null;
/*      */     try {
/* 1067 */       inputStream = new BufferedInputStream(new FileInputStream(fileToUpload));
/* 1068 */       InstallReceiver receiver = new InstallReceiver();
/* 1069 */       AdbHelper.executeRemoteCommand(AndroidDebugBridge.getSocketAddress(), AdbHelper.AdbService.EXEC, command, this, receiver, timeOutInMs, TimeUnit.MILLISECONDS, inputStream);
/*      */ 
/* 1072 */       if (receiver.getErrorMessage() != null) {
/* 1073 */         Log.e(sessionId, String.format("Error while uploading %1$s : %2$s", new Object[] { fileToUpload.getName(), receiver.getErrorMessage() }));
/*      */       }
/*      */       else {
/* 1076 */         Log.d(sessionId, String.format("Successfully uploaded %1$s", new Object[] { fileToUpload.getName() }));
/*      */       }
/* 1078 */       return receiver.getErrorMessage() == null;
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */       boolean bool;
/* 1080 */       Log.e(sessionId, e);
/* 1081 */       return false;
/*      */     } finally {
/* 1083 */       if (inputStream != null)
/*      */         try {
/* 1085 */           inputStream.close();
/*      */         } catch (IOException e) {
/* 1087 */           Log.e(sessionId, e);
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   public String syncPackageToDevice(String localFilePath)
/*      */     throws IOException, AdbCommandRejectedException, TimeoutException, SyncException
/*      */   {
/* 1097 */     SyncService sync = null;
/*      */     try {
/* 1099 */       String packageFileName = getFileName(localFilePath);
/* 1100 */       String remoteFilePath = String.format("/data/local/tmp/%1$s", new Object[] { packageFileName });
/*      */ 
/* 1102 */       Log.d(packageFileName, String.format("Uploading %1$s onto device '%2$s'", new Object[] { packageFileName, getSerialNumber() }));
/*      */ 
/* 1105 */       sync = getSyncService();
/*      */       String message;
/* 1106 */       if (sync != null) {
/* 1107 */         message = String.format("Uploading file onto device '%1$s'", new Object[] { getSerialNumber() });
/*      */ 
/* 1109 */         Log.d("Device", message);
/* 1110 */         sync.pushFile(localFilePath, remoteFilePath, SyncService.getNullProgressMonitor());
/*      */       } else {
/* 1112 */         throw new IOException("Unable to open sync connection!");
/*      */       }
/* 1114 */       return remoteFilePath;
/*      */     } catch (TimeoutException e) {
/* 1116 */       Log.e("Device", "Error during Sync: timeout.");
/* 1117 */       throw e;
/*      */     }
/*      */     catch (SyncException e) {
/* 1120 */       Log.e("Device", String.format("Error during Sync: %1$s", new Object[] { e.getMessage() }));
/* 1121 */       throw e;
/*      */     }
/*      */     catch (IOException e) {
/* 1124 */       Log.e("Device", String.format("Error during Sync: %1$s", new Object[] { e.getMessage() }));
/* 1125 */       throw e;
/*      */     }
/*      */     finally {
/* 1128 */       if (sync != null)
/* 1129 */         sync.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static String getFileName(String filePath)
/*      */   {
/* 1140 */     return new File(filePath).getName();
/*      */   }
/*      */ 
/*      */   public void installRemotePackage(String remoteFilePath, boolean reinstall, String[] extraArgs) throws InstallException
/*      */   {
/*      */     try
/*      */     {
/* 1147 */       InstallReceiver receiver = new InstallReceiver();
/* 1148 */       StringBuilder optionString = new StringBuilder();
/* 1149 */       if (reinstall) {
/* 1150 */         optionString.append("-r ");
/*      */       }
/* 1152 */       if (extraArgs != null) {
/* 1153 */         optionString.append(Joiner.on(' ').join(extraArgs));
/*      */       }
/* 1155 */       String cmd = String.format("pm install %1$s \"%2$s\"", new Object[] { optionString.toString(), remoteFilePath });
/*      */ 
/* 1157 */       executeShellCommand(cmd, receiver, INSTALL_TIMEOUT_MINUTES, TimeUnit.MINUTES);
/* 1158 */       String error = receiver.getErrorMessage();
/* 1159 */       if (error != null)
/* 1160 */         throw new InstallException(error);
/*      */     }
/*      */     catch (TimeoutException e) {
/* 1163 */       throw new InstallException(e);
/*      */     } catch (AdbCommandRejectedException e) {
/* 1165 */       throw new InstallException(e);
/*      */     } catch (ShellCommandUnresponsiveException e) {
/* 1167 */       throw new InstallException(e);
/*      */     } catch (IOException e) {
/* 1169 */       throw new InstallException(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void removeRemotePackage(String remoteFilePath) throws InstallException
/*      */   {
/*      */     try {
/* 1176 */       executeShellCommand(String.format("rm \"%1$s\"", new Object[] { remoteFilePath }), new NullOutputReceiver(), INSTALL_TIMEOUT_MINUTES, TimeUnit.MINUTES);
/*      */     }
/*      */     catch (IOException e) {
/* 1179 */       throw new InstallException(e);
/*      */     } catch (TimeoutException e) {
/* 1181 */       throw new InstallException(e);
/*      */     } catch (AdbCommandRejectedException e) {
/* 1183 */       throw new InstallException(e);
/*      */     } catch (ShellCommandUnresponsiveException e) {
/* 1185 */       throw new InstallException(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public String uninstallPackage(String packageName) throws InstallException
/*      */   {
/*      */     try {
/* 1192 */       InstallReceiver receiver = new InstallReceiver();
/* 1193 */       executeShellCommand(new StringBuilder().append("pm uninstall ").append(packageName).toString(), receiver, INSTALL_TIMEOUT_MINUTES, TimeUnit.MINUTES);
/*      */ 
/* 1195 */       return receiver.getErrorMessage();
/*      */     } catch (TimeoutException e) {
/* 1197 */       throw new InstallException(e);
/*      */     } catch (AdbCommandRejectedException e) {
/* 1199 */       throw new InstallException(e);
/*      */     } catch (ShellCommandUnresponsiveException e) {
/* 1201 */       throw new InstallException(e);
/*      */     } catch (IOException e) {
/* 1203 */       throw new InstallException(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void reboot(String into)
/*      */     throws TimeoutException, AdbCommandRejectedException, IOException
/*      */   {
/* 1214 */     AdbHelper.reboot(into, AndroidDebugBridge.getSocketAddress(), this);
/*      */   }
/*      */ 
/*      */   public boolean root() throws TimeoutException, AdbCommandRejectedException, IOException, ShellCommandUnresponsiveException
/*      */   {
/* 1219 */     if (!this.mIsRoot) {
/* 1220 */       AdbHelper.root(AndroidDebugBridge.getSocketAddress(), this);
/*      */     }
/* 1222 */     return isRoot();
/*      */   }
/*      */ 
/*      */   public boolean isRoot() throws TimeoutException, AdbCommandRejectedException, ShellCommandUnresponsiveException, IOException
/*      */   {
/* 1227 */     if (this.mIsRoot) {
/* 1228 */       return true;
/*      */     }
/* 1230 */     CollectingOutputReceiver receiver = new CollectingOutputReceiver();
/* 1231 */     executeShellCommand("echo $USER_ID", receiver, 1000L, TimeUnit.MILLISECONDS);
/* 1232 */     String userID = receiver.getOutput().trim();
/* 1233 */     this.mIsRoot = userID.equals("0");
/* 1234 */     return this.mIsRoot;
/*      */   }
/*      */ 
/*      */   public Integer getBatteryLevel()
/*      */     throws TimeoutException, AdbCommandRejectedException, IOException, ShellCommandUnresponsiveException
/*      */   {
/* 1241 */     return getBatteryLevel(300000L);
/*      */   }
/*      */ 
/*      */   public Integer getBatteryLevel(long freshnessMs)
/*      */     throws TimeoutException, AdbCommandRejectedException, IOException, ShellCommandUnresponsiveException
/*      */   {
/* 1247 */     Future futureBattery = getBattery(freshnessMs, TimeUnit.MILLISECONDS);
/*      */     try {
/* 1249 */       return (Integer)futureBattery.get();
/*      */     } catch (InterruptedException e) {
/* 1251 */       return null; } catch (ExecutionException e) {
/*      */     }
/* 1253 */     return null;
/*      */   }
/*      */ 
/*      */   public Future<Integer> getBattery()
/*      */   {
/* 1260 */     return getBattery(5L, TimeUnit.MINUTES);
/*      */   }
/*      */ 
/*      */   public Future<Integer> getBattery(long freshnessTime, TimeUnit timeUnit)
/*      */   {
/* 1266 */     return this.mBatteryFetcher.getBattery(freshnessTime, timeUnit);
/*      */   }
/*      */ 
/*      */   public List<String> getAbis()
/*      */   {
/* 1273 */     String abiList = getProperty("ro.product.cpu.abilist");
/* 1274 */     if (abiList != null) {
/* 1275 */       return Lists.newArrayList(abiList.split(","));
/*      */     }
/* 1277 */     List abis = Lists.newArrayListWithExpectedSize(2);
/* 1278 */     String abi = getProperty("ro.product.cpu.abi");
/* 1279 */     if (abi != null) {
/* 1280 */       abis.add(abi);
/*      */     }
/*      */ 
/* 1283 */     abi = getProperty("ro.product.cpu.abi2");
/* 1284 */     if (abi != null) {
/* 1285 */       abis.add(abi);
/*      */     }
/*      */ 
/* 1288 */     return abis;
/*      */   }
/*      */ 
/*      */   public int getDensity()
/*      */   {
/* 1294 */     String densityValue = getProperty("ro.sf.lcd_density");
/* 1295 */     if (densityValue != null) {
/*      */       try {
/* 1297 */         return Integer.parseInt(densityValue);
/*      */       } catch (NumberFormatException e) {
/* 1299 */         return -1;
/*      */       }
/*      */     }
/*      */ 
/* 1303 */     return -1;
/*      */   }
/*      */ 
/*      */   public String getLanguage()
/*      */   {
/* 1308 */     return (String)getProperties().get("persist.sys.language");
/*      */   }
/*      */ 
/*      */   public String getRegion()
/*      */   {
/* 1313 */     return getProperty("persist.sys.country");
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  100 */     String installTimeout = System.getenv("ADB_INSTALL_TIMEOUT");
/*  101 */     long time = 4L;
/*  102 */     if (installTimeout != null)
/*      */       try {
/*  104 */         time = Long.parseLong(installTimeout);
/*      */       }
/*      */       catch (NumberFormatException e)
/*      */       {
/*      */       }
/*      */   }
/*      */ 
/*      */   private static class MultiInstallReceiver extends MultiLineReceiver
/*      */   {
/*  980 */     private static final Pattern successPattern = Pattern.compile("Success: .*\\[(\\d*)\\]");
/*      */ 
/*  982 */     String sessionId = null;
/*      */ 
/*      */     public boolean isCancelled()
/*      */     {
/*  986 */       return false;
/*      */     }
/*      */ 
/*      */     public void processNewLines(String[] lines)
/*      */     {
/*  991 */       for (String line : lines) {
/*  992 */         Matcher matcher = successPattern.matcher(line);
/*  993 */         if (matcher.matches())
/*  994 */           this.sessionId = matcher.group(1);
/*      */       }
/*      */     }
/*      */ 
/*      */     public String getSessionId()
/*      */     {
/* 1002 */       return this.sessionId;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static final class InstallReceiver extends MultiLineReceiver
/*      */   {
/*      */     private static final String SUCCESS_OUTPUT = "Success";
/*  139 */     private static final Pattern FAILURE_PATTERN = Pattern.compile("Failure\\s+\\[(.*)\\]");
/*      */ 
/*  141 */     private String mErrorMessage = null;
/*      */ 
/*      */     public void processNewLines(String[] lines)
/*      */     {
/*  148 */       for (String line : lines)
/*  149 */         if (!line.isEmpty())
/*  150 */           if (line.startsWith("Success")) {
/*  151 */             this.mErrorMessage = null;
/*      */           } else {
/*  153 */             Matcher m = FAILURE_PATTERN.matcher(line);
/*  154 */             if (m.matches())
/*  155 */               this.mErrorMessage = m.group(1);
/*      */             else
/*  157 */               this.mErrorMessage = ("Unknown failure (" + line + ")");
/*      */           }
/*      */     }
/*      */ 
/*      */     public boolean isCancelled()
/*      */     {
/*  166 */       return false;
/*      */     }
/*      */ 
/*      */     public String getErrorMessage() {
/*  170 */       return this.mErrorMessage;
/*      */     }
/*      */   }
/*      */ }

/* Location:           /disk/B/share/ddmlib/ddmlib-24.5.0-beta2.jar
 * Qualified Name:     com.android.ddmlib.Device
 * JD-Core Version:    0.6.2
 */